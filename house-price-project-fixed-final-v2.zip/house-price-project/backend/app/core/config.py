from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


BASE_DIR = Path(__file__).resolve().parents[2]


class Settings(BaseSettings):
    """Application settings, loaded from environment variables / .env file."""

    model_config = SettingsConfigDict(
        env_file=BASE_DIR / ".env",
        extra="ignore",
        protected_namespaces=("settings_",),
    )

    app_name: str = "House Price Prediction API"
    model_path: str = str(BASE_DIR / "models" / "house_price.pkl")
    locations_path: str = str(BASE_DIR / "models" / "locations.json")
    metadata_path: str = str(BASE_DIR / "models" / "model_metadata.json")
    cors_origins: list[str] = [
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ]
    log_level: str = "INFO"


@lru_cache
def get_settings() -> Settings:
    return Settings()
