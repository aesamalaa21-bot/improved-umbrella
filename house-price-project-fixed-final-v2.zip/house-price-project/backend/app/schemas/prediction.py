from typing import Literal
from pydantic import BaseModel, Field


class PredictionRequest(BaseModel):
    """Payload sent by the frontend form. Field names/types mirror the
    columns the model's sklearn Pipeline was trained on."""

    location: str = Field(..., description="Locality/area name, e.g. 'Whitefield'")
    carpet_area_sqft: float = Field(..., gt=0, description="Carpet area in square feet")
    floor_num: int = Field(..., ge=0, description="Floor number (0 = ground)")
    bathroom: int = Field(..., ge=0, le=20)
    balcony: int = Field(..., ge=0, le=20)
    furnishing: Literal["Furnished", "Semi-Furnished", "Unfurnished"]
    transaction: Literal["New Property", "Resale"]
    ownership: str = Field(..., description="e.g. 'Freehold', 'Leasehold', 'Co-operative Society'")
    facing: str = Field(..., description="e.g. 'East', 'North', 'West'")

    model_config = {
        "json_schema_extra": {
            "example": {
                "location": "Whitefield",
                "carpet_area_sqft": 1200,
                "floor_num": 3,
                "bathroom": 2,
                "balcony": 1,
                "furnishing": "Semi-Furnished",
                "transaction": "Resale",
                "ownership": "Freehold",
                "facing": "East",
            }
        }
    }


class PredictionResponse(BaseModel):
    predicted_price: float


class HealthResponse(BaseModel):
    status: str = "ok"
