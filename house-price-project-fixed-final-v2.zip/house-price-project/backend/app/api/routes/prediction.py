import logging

from fastapi import APIRouter, HTTPException

from app.schemas.prediction import HealthResponse, PredictionRequest, PredictionResponse
from app.services.inference import prediction_service

logger = logging.getLogger(__name__)
router = APIRouter()


@router.get("/health", response_model=HealthResponse)
def health() -> HealthResponse:
    if not prediction_service.is_ready:
        raise HTTPException(status_code=503, detail="Model is not loaded")
    return HealthResponse(status="ok")


@router.get("/locations")
def locations() -> list[str]:
    """List of locations the frontend dropdown should offer."""
    return prediction_service.allowed_locations


@router.post("/predict", response_model=PredictionResponse)
def predict(payload: PredictionRequest) -> PredictionResponse:
    try:
        price = prediction_service.predict(payload)
    except RuntimeError as exc:
        logger.exception("Prediction failed")
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:  # noqa: BLE001 - surface as a clean 500 to the client
        logger.exception("Unexpected error during prediction")
        raise HTTPException(status_code=500, detail="Prediction failed") from exc

    return PredictionResponse(predicted_price=round(price, 2))
