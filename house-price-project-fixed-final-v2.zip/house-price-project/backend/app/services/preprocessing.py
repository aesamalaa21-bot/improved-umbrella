import pandas as pd

from app.schemas.prediction import PredictionRequest

# Must match `numeric_features + categorical_features` from the training notebook exactly.
NUMERIC_FEATURES = ["carpet_area_sqft", "floor_num", "bathroom", "balcony"]
CATEGORICAL_FEATURES = ["location_grouped", "Furnishing", "Transaction", "Ownership", "facing"]


def request_to_dataframe(payload: PredictionRequest, allowed_locations: set[str]) -> pd.DataFrame:
    """Turn a validated request into the single-row DataFrame the exported
    sklearn Pipeline expects. Unknown locations are mapped to 'other', the
    same bucket used for rare locations during training.
    """
    location = payload.location if payload.location in allowed_locations else "other"

    row = {
        "carpet_area_sqft": payload.carpet_area_sqft,
        "floor_num": payload.floor_num,
        "bathroom": payload.bathroom,
        "balcony": payload.balcony,
        "location_grouped": location,
        "Furnishing": payload.furnishing,
        "Transaction": payload.transaction,
        "Ownership": payload.ownership,
        "facing": payload.facing,
    }

    return pd.DataFrame([row], columns=NUMERIC_FEATURES + CATEGORICAL_FEATURES)
