import json
import logging
from pathlib import Path

import joblib
import numpy as np

from app.core.config import Settings
from app.schemas.prediction import PredictionRequest
from app.services.preprocessing import request_to_dataframe

logger = logging.getLogger(__name__)


class PredictionService:
    """Loads the exported sklearn Pipeline and its metadata at application startup."""

    def __init__(self, settings: Settings):
        self._settings = settings
        self._model = None
        self._allowed_locations: set[str] = set()
        self._log_target = False
        self._metadata: dict = {}

    def load(self) -> None:
        model_path = Path(self._settings.model_path)
        locations_path = Path(self._settings.locations_path)
        metadata_path = Path(self._settings.metadata_path)

        missing = [
            str(path)
            for path in (model_path, locations_path, metadata_path)
            if not path.exists()
        ]
        if missing:
            raise FileNotFoundError(
                "Required trained model artifacts are missing: "
                + ", ".join(missing)
                + ". Run the notebook with Kernel -> Restart & Run All first."
            )

        with open(metadata_path, encoding="utf-8") as f:
            self._metadata = json.load(f)

        self._model = joblib.load(model_path)
        self._log_target = bool(self._metadata.get("log_target", False))

        with open(locations_path, encoding="utf-8") as f:
            self._allowed_locations = set(json.load(f))

        logger.info(
            "Loaded model=%s target=%s sklearn=%s locations=%d",
            self._metadata.get("model_name"),
            self._metadata.get("target"),
            self._metadata.get("sklearn_version"),
            len(self._allowed_locations),
        )

    @property
    def is_ready(self) -> bool:
        return self._model is not None

    @property
    def allowed_locations(self) -> list[str]:
        return sorted(self._allowed_locations)

    @property
    def metadata(self) -> dict:
        return self._metadata

    def predict(self, payload: PredictionRequest) -> float:
        if self._model is None:
            raise RuntimeError("Prediction model is not loaded")

        df = request_to_dataframe(payload, self._allowed_locations)
        raw_pred = self._model.predict(df)[0]
        price = float(np.expm1(raw_pred)) if self._log_target else float(raw_pred)
        return max(price, 0.0)


prediction_service = PredictionService(Settings())
