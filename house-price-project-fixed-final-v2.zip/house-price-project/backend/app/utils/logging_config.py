import logging
import sys


def configure_logging(level: str = "INFO") -> None:
    """Configure a simple, consistent logging format for the whole app."""
    logging.basicConfig(
        level=level,
        format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        stream=sys.stdout,
    )
