Put the trained artifacts here after running the notebook:

- `house_price.pkl`   (exported sklearn Pipeline)
- `locations.json`    (list of allowed location strings for the dropdown)

Neither file is committed to git if `house_price.pkl` is 50MB+; see the root .gitignore.
