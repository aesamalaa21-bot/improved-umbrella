import numpy as np
import pandas as pd
import pytest
from fastapi.testclient import TestClient
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from app.main import app
from app.services.inference import prediction_service


NUMERIC_FEATURES = ["carpet_area_sqft", "floor_num", "bathroom", "balcony"]
CATEGORICAL_FEATURES = ["location_grouped", "Furnishing", "Transaction", "Ownership", "facing"]

VALID_PAYLOAD = {
    "location": "Whitefield",
    "carpet_area_sqft": 1200,
    "floor_num": 3,
    "bathroom": 2,
    "balcony": 1,
    "furnishing": "Semi-Furnished",
    "transaction": "Resale",
    "ownership": "Freehold",
    "facing": "East",
}


@pytest.fixture(autouse=True)
def stub_model(monkeypatch):
    """Train a tiny throwaway pipeline in-memory so tests don't require the
    real house_price.pkl artifact to be present.
    """
    rng = np.random.default_rng(42)
    n = 50
    df = pd.DataFrame(
        {
            "carpet_area_sqft": rng.uniform(400, 3000, n),
            "floor_num": rng.integers(0, 15, n),
            "bathroom": rng.integers(1, 4, n),
            "balcony": rng.integers(0, 3, n),
            "location_grouped": rng.choice(["Whitefield", "other"], n),
            "Furnishing": rng.choice(["Furnished", "Semi-Furnished", "Unfurnished"], n),
            "Transaction": rng.choice(["New Property", "Resale"], n),
            "Ownership": rng.choice(["Freehold", "Leasehold"], n),
            "facing": rng.choice(["East", "West", "North"], n),
        }
    )
    y = df["carpet_area_sqft"] * 5000 + rng.normal(0, 1000, n)

    preprocessor = ColumnTransformer(
        [
            ("num", Pipeline([("impute", SimpleImputer(strategy="median")), ("scale", StandardScaler())]), NUMERIC_FEATURES),
            (
                "cat",
                Pipeline([("impute", SimpleImputer(strategy="most_frequent")), ("onehot", OneHotEncoder(handle_unknown="ignore"))]),
                CATEGORICAL_FEATURES,
            ),
        ]
    )
    model = Pipeline([("prep", preprocessor), ("reg", RandomForestRegressor(n_estimators=10, random_state=42))])
    model.fit(df[NUMERIC_FEATURES + CATEGORICAL_FEATURES], y)

    prediction_service._model = model
    prediction_service._allowed_locations = {"Whitefield"}
    prediction_service._log_target = False
    # Prevent the FastAPI lifespan from overwriting our stub by reloading
    # from a (non-existent, in this test env) file on disk.
    monkeypatch.setattr(prediction_service, "load", lambda: None)
    yield
    prediction_service._model = None
    prediction_service._allowed_locations = set()


@pytest.fixture
def client():
    with TestClient(app) as c:
        yield c


def test_health(client):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_predict_happy_path(client):
    response = client.post("/predict", json=VALID_PAYLOAD)
    assert response.status_code == 200
    body = response.json()
    assert "predicted_price" in body
    assert body["predicted_price"] > 0


def test_predict_invalid_input(client):
    bad_payload = {**VALID_PAYLOAD, "carpet_area_sqft": -100}  # violates gt=0
    response = client.post("/predict", json=bad_payload)
    assert response.status_code == 422


def test_predict_invalid_enum(client):
    bad_payload = {**VALID_PAYLOAD, "furnishing": "Not-A-Real-Option"}
    response = client.post("/predict", json=bad_payload)
    assert response.status_code == 422
