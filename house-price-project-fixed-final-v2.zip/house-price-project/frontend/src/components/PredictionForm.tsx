import { FormEvent, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ApiRequestError, fetchLocations, predictPrice } from "../api/predictionClient";
import type { PredictionRequest } from "../types/prediction";
import type { EstimateRecord } from "../App";

const FURNISHING_OPTIONS = ["Furnished", "Semi-Furnished", "Unfurnished"] as const;
const TRANSACTION_OPTIONS = ["New Property", "Resale"] as const;
const OWNERSHIP_OPTIONS = ["Freehold", "Leasehold", "Co-operative Society", "Power of Attorney"];
const FACING_OPTIONS = ["East", "West", "North", "South", "North-East", "North-West", "South-East", "South-West"];

const initialForm: PredictionRequest = {
  location: "",
  carpet_area_sqft: 0,
  floor_num: 0,
  bathroom: 1,
  balcony: 0,
  furnishing: "Semi-Furnished",
  transaction: "Resale",
  ownership: "Freehold",
  facing: "East",
};

type FormErrors = Partial<Record<keyof PredictionRequest, string>>;

function validate(form: PredictionRequest): FormErrors {
  const errors: FormErrors = {};
  if (!form.location.trim()) errors.location = "Choose a location.";
  if (!form.carpet_area_sqft || form.carpet_area_sqft <= 0) errors.carpet_area_sqft = "Enter an area greater than 0.";
  if (form.floor_num < 0) errors.floor_num = "Floor can't be negative.";
  if (form.bathroom < 0) errors.bathroom = "Bathrooms can't be negative.";
  if (form.balcony < 0) errors.balcony = "Balconies can't be negative.";
  if (!form.ownership.trim()) errors.ownership = "Choose an ownership type.";
  return errors;
}

interface Props {
  onEstimate: (record: EstimateRecord) => void;
}

export default function PredictionForm({ onEstimate }: Props) {
  const navigate = useNavigate();
  const [form, setForm] = useState<PredictionRequest>(initialForm);
  const [errors, setErrors] = useState<FormErrors>({});
  const [locations, setLocations] = useState<string[]>([]);
  const [locationsError, setLocationsError] = useState<string | null>(null);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    fetchLocations()
      .then(setLocations)
      .catch(() => setLocationsError("Couldn't load the list of locations — you can still type one in manually."));
  }, []);

  function update<K extends keyof PredictionRequest>(key: K, value: PredictionRequest[K]) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  async function handleSubmit(event: FormEvent) {
    event.preventDefault();
    const validationErrors = validate(form);
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) return;

    setSubmitError(null);
    setIsSubmitting(true);
    try {
      const response = await predictPrice(form);
      onEstimate({ request: form, response });
      navigate("/result");
    } catch (err) {
      const message = err instanceof ApiRequestError ? err.message : "Couldn't reach the prediction service. Is the backend running?";
      setSubmitError(message);
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <form className="card" onSubmit={handleSubmit} noValidate>
      {submitError && <div className="banner banner--error">{submitError}</div>}
      {locationsError && <div className="banner banner--error">{locationsError}</div>}

      <div className="form-grid">
        <div className={`field ${errors.location ? "field--invalid" : ""}`}>
          <label htmlFor="location">Location</label>
          {locations.length > 0 ? (
            <select id="location" value={form.location} onChange={(e) => update("location", e.target.value)}>
              <option value="" disabled>
                Select a location
              </option>
              {locations.map((loc) => (
                <option key={loc} value={loc}>
                  {loc}
                </option>
              ))}
            </select>
          ) : (
            <input
              id="location"
              type="text"
              placeholder="e.g. Whitefield"
              value={form.location}
              onChange={(e) => update("location", e.target.value)}
            />
          )}
          {errors.location && <span className="field-error">{errors.location}</span>}
        </div>

        <div className={`field ${errors.carpet_area_sqft ? "field--invalid" : ""}`}>
          <label htmlFor="carpet_area_sqft">Carpet area (sqft)</label>
          <input
            id="carpet_area_sqft"
            type="number"
            min={1}
            value={form.carpet_area_sqft || ""}
            onChange={(e) => update("carpet_area_sqft", Number(e.target.value))}
          />
          {errors.carpet_area_sqft && <span className="field-error">{errors.carpet_area_sqft}</span>}
        </div>

        <div className={`field ${errors.floor_num ? "field--invalid" : ""}`}>
          <label htmlFor="floor_num">Floor number</label>
          <input
            id="floor_num"
            type="number"
            min={0}
            value={form.floor_num}
            onChange={(e) => update("floor_num", Number(e.target.value))}
          />
          {errors.floor_num && <span className="field-error">{errors.floor_num}</span>}
        </div>

        <div className={`field ${errors.bathroom ? "field--invalid" : ""}`}>
          <label htmlFor="bathroom">Bathrooms</label>
          <input
            id="bathroom"
            type="number"
            min={0}
            value={form.bathroom}
            onChange={(e) => update("bathroom", Number(e.target.value))}
          />
          {errors.bathroom && <span className="field-error">{errors.bathroom}</span>}
        </div>

        <div className={`field ${errors.balcony ? "field--invalid" : ""}`}>
          <label htmlFor="balcony">Balconies</label>
          <input
            id="balcony"
            type="number"
            min={0}
            value={form.balcony}
            onChange={(e) => update("balcony", Number(e.target.value))}
          />
          {errors.balcony && <span className="field-error">{errors.balcony}</span>}
        </div>

        <div className="field">
          <label htmlFor="furnishing">Furnishing</label>
          <select id="furnishing" value={form.furnishing} onChange={(e) => update("furnishing", e.target.value as PredictionRequest["furnishing"])}>
            {FURNISHING_OPTIONS.map((opt) => (
              <option key={opt} value={opt}>
                {opt}
              </option>
            ))}
          </select>
        </div>

        <div className="field">
          <label htmlFor="transaction">Transaction type</label>
          <select id="transaction" value={form.transaction} onChange={(e) => update("transaction", e.target.value as PredictionRequest["transaction"])}>
            {TRANSACTION_OPTIONS.map((opt) => (
              <option key={opt} value={opt}>
                {opt}
              </option>
            ))}
          </select>
        </div>

        <div className={`field ${errors.ownership ? "field--invalid" : ""}`}>
          <label htmlFor="ownership">Ownership</label>
          <select id="ownership" value={form.ownership} onChange={(e) => update("ownership", e.target.value)}>
            {OWNERSHIP_OPTIONS.map((opt) => (
              <option key={opt} value={opt}>
                {opt}
              </option>
            ))}
          </select>
          {errors.ownership && <span className="field-error">{errors.ownership}</span>}
        </div>

        <div className="field">
          <label htmlFor="facing">Facing</label>
          <select id="facing" value={form.facing} onChange={(e) => update("facing", e.target.value)}>
            {FACING_OPTIONS.map((opt) => (
              <option key={opt} value={opt}>
                {opt}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="form-footer">
        <span className="form-note">All fields required</span>
        <button type="submit" className="primary" disabled={isSubmitting}>
          {isSubmitting ? "Estimating…" : "Get estimate"}
        </button>
      </div>
    </form>
  );
}
