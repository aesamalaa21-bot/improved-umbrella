import type { ApiError, PredictionRequest, PredictionResponse } from "../types/prediction";

const BASE_URL = import.meta.env.VITE_API_BASE_URL ?? "http://localhost:8000";

export class ApiRequestError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.name = "ApiRequestError";
    this.status = status;
  }
}

function extractErrorMessage(body: ApiError): string {
  if (typeof body.detail === "string") return body.detail;
  if (Array.isArray(body.detail)) {
    return body.detail.map((e) => e.msg).join(", ");
  }
  return "Something went wrong. Please try again.";
}

export async function fetchLocations(): Promise<string[]> {
  const response = await fetch(`${BASE_URL}/locations`);
  if (!response.ok) {
    throw new ApiRequestError("Could not load the list of locations.", response.status);
  }
  return response.json();
}

export async function predictPrice(payload: PredictionRequest): Promise<PredictionResponse> {
  const response = await fetch(`${BASE_URL}/predict`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    const body = (await response.json().catch(() => ({ detail: "Prediction request failed." }))) as ApiError;
    throw new ApiRequestError(extractErrorMessage(body), response.status);
  }

  return response.json();
}
