import { useState } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import HomePage from "./pages/HomePage";
import ResultPage from "./pages/ResultPage";
import NotFoundPage from "./pages/NotFoundPage";
import type { PredictionRequest, PredictionResponse } from "./types/prediction";

export interface EstimateRecord {
  request: PredictionRequest;
  response: PredictionResponse;
}

/**
 * Simple in-memory router. The last estimate is lifted to App so the
 * result page can render it without an extra API round-trip.
 */
export default function App() {
  const [lastEstimate, setLastEstimate] = useState<EstimateRecord | null>(null);

  return (
    <BrowserRouter>
      <div className="app-shell">
        <header className="site-header">
          <div className="site-header__eyebrow">Property Valuation Desk</div>
          <h1>House Price Estimator</h1>
          <p>
            Enter the property details below and get an instant, model-based estimate — trained on real
            listings and served by a FastAPI backend.
          </p>
        </header>
        <main>
          <Routes>
            <Route path="/" element={<HomePage onEstimate={setLastEstimate} />} />
            <Route path="/result" element={<ResultPage estimate={lastEstimate} />} />
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  );
}
