import { Navigate, Link } from "react-router-dom";
import type { EstimateRecord } from "../App";

interface Props {
  estimate: EstimateRecord | null;
}

/** Formats a rupee amount the way Indian listings do: ₹42.50 Lac or ₹1.35 Cr. */
function formatIndianPrice(amount: number): string {
  if (amount >= 1e7) return `₹${(amount / 1e7).toFixed(2)} Cr`;
  if (amount >= 1e5) return `₹${(amount / 1e5).toFixed(2)} Lac`;
  return `₹${amount.toLocaleString("en-IN")}`;
}

export default function ResultPage({ estimate }: Props) {
  if (!estimate) {
    // Someone navigated to /result directly without submitting the form.
    return <Navigate to="/" replace />;
  }

  const { request, response } = estimate;

  return (
    <div className="ticket" style={{ maxWidth: 620, width: "100%" }}>
      <span className="ticket__stamp">Certified estimate</span>
      <div className="ticket__label">Estimated market value</div>
      <p className="ticket__price">{formatIndianPrice(response.predicted_price)}</p>
      <p className="ticket__meta">₹{Math.round(response.predicted_price).toLocaleString("en-IN")} exact</p>

      <hr className="ticket__divider" />

      <dl className="ticket__specs">
        <div className="ticket__spec">
          <dt>Location</dt>
          <dd>{request.location}</dd>
        </div>
        <div className="ticket__spec">
          <dt>Carpet area</dt>
          <dd>{request.carpet_area_sqft} sqft</dd>
        </div>
        <div className="ticket__spec">
          <dt>Floor</dt>
          <dd>{request.floor_num}</dd>
        </div>
        <div className="ticket__spec">
          <dt>Bathrooms</dt>
          <dd>{request.bathroom}</dd>
        </div>
        <div className="ticket__spec">
          <dt>Balconies</dt>
          <dd>{request.balcony}</dd>
        </div>
        <div className="ticket__spec">
          <dt>Furnishing</dt>
          <dd>{request.furnishing}</dd>
        </div>
        <div className="ticket__spec">
          <dt>Transaction</dt>
          <dd>{request.transaction}</dd>
        </div>
        <div className="ticket__spec">
          <dt>Facing</dt>
          <dd>{request.facing}</dd>
        </div>
      </dl>

      <div className="ticket__actions">
        <Link to="/" className="ghost" style={{ textDecoration: "none", display: "inline-block" }}>
          New estimate
        </Link>
      </div>
    </div>
  );
}
