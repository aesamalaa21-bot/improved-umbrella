import PredictionForm from "../components/PredictionForm";
import type { EstimateRecord } from "../App";

interface Props {
  onEstimate: (record: EstimateRecord) => void;
}

export default function HomePage({ onEstimate }: Props) {
  return <PredictionForm onEstimate={onEstimate} />;
}
