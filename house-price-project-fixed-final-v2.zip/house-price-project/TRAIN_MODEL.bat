@echo off
setlocal
cd /d "%~dp0"

if not exist "notebooks\data\house_prices.csv" (
    echo ERROR: notebooks\data\house_prices.csv was not found.
    echo Download the Kaggle dataset and place house_prices.csv in notebooks\data.
    pause
    exit /b 1
)

if not exist "notebooks\.venv" (
    echo Creating notebook virtual environment...
    python -m venv notebooks\.venv
)

echo Installing notebook dependencies...
call notebooks\.venv\Scripts\activate.bat
pip install -r notebooks\requirements.txt

echo.
echo Open notebooks\house_price_model.ipynb in Jupyter.
echo Run: Kernel - Restart & Run All
echo.
echo The trained artifacts will be exported automatically to:
echo backend\models\
echo.
jupyter notebook notebooks\house_price_model.ipynb
endlocal
