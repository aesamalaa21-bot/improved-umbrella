@echo off
setlocal
cd /d "%~dp0"

echo ============================================
echo   House Price Prediction - Project Starter
echo ============================================
echo.

if not exist "backend\models\house_price.pkl" (
    echo ERROR: backend\models\house_price.pkl is missing.
    echo Run TRAIN_MODEL.bat first, then run this file again.
    pause
    exit /b 1
)

if not exist "backend\models\locations.json" (
    echo ERROR: backend\models\locations.json is missing.
    echo Run TRAIN_MODEL.bat first, then run this file again.
    pause
    exit /b 1
)

if not exist "backend\models\model_metadata.json" (
    echo ERROR: backend\models\model_metadata.json is missing.
    echo Run TRAIN_MODEL.bat first, then run this file again.
    pause
    exit /b 1
)

if not exist "backend\.venv" (
    echo Creating backend virtual environment...
    python -m venv backend\.venv
)

if not exist "frontend\node_modules" (
    echo Installing frontend dependencies...
    cd /d "%~dp0frontend"
    call npm install
    if errorlevel 1 (
        echo ERROR: npm install failed.
        pause
        exit /b 1
    )
    cd /d "%~dp0"
)

echo [1/2] Starting FastAPI backend...
start "House Price Backend" cmd /k "cd /d "%~dp0backend" && call .venv\Scripts\activate.bat && pip install -r requirements.txt && uvicorn app.main:app --host 127.0.0.1 --port 8000"

timeout /t 3 /nobreak >nul

echo [2/2] Starting React frontend...
start "House Price Frontend" cmd /k "cd /d "%~dp0frontend" && npm run dev -- --host 127.0.0.1 --port 5173"

echo.
echo Backend Swagger: http://127.0.0.1:8000/docs
echo Backend Health:  http://127.0.0.1:8000/health
echo Frontend:        http://127.0.0.1:5173
echo.
endlocal
